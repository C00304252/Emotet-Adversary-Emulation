# payload.ps1
Start-Sleep -Seconds 2
Write-Output "Simulating payload download..."
Start-Process notepad.exe
